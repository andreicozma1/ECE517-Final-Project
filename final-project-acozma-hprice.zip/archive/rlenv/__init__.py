__all__ = ['pongGame']

from .pongclass import pongGame
